package com.codingexercise.stocktaker.repository;

import com.codingexercise.stocktaker.model.Product;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface ProductRepository<T> extends CrudRepository<Product, String> {

    @Query(
            value = "UPDATE Product SET minimumStockLevel =:minimumStockLevel WHERE productName =:productName",
            nativeQuery = true
    )
    void updateMinimumStockLevel(@Param("minimumStockLevel") Integer minimumStockLevel, @Param("productName") String productName);

    Product findByProductName(String name);

}
