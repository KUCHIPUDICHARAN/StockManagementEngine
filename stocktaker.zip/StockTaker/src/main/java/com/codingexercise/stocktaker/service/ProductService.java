package com.codingexercise.stocktaker.service;

import com.codingexercise.stocktaker.model.Product;

import java.util.List;

public interface ProductService {

    void saveProducts(List<Product> products);

    Product findProductByName(String name);

    List<Product> getAllProducts();

    void updateProductDetails(Product name);

    List<Product> getAllProductsToOrder();
}
