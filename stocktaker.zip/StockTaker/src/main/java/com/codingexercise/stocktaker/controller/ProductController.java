package com.codingexercise.stocktaker.controller;

import com.codingexercise.stocktaker.exception.ProductNotFoundException;
import com.codingexercise.stocktaker.model.Product;
import com.codingexercise.stocktaker.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class ProductController {

    @Autowired
    private ProductService productService;

    /*
    End point to get product details by name
     http://localhost:8080/getProductByName?productName="Apple"
     */
    @RequestMapping(value = "/getProductByName", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public Product getProductByName(@RequestParam(required = true) String productName) {
        Product product = productService.findProductByName(productName);
        if (product == null) {
            throw new ProductNotFoundException("No such product available with the given name" + productName);
        }
        return product;
    }

    /*
    End point to get all product details including blocked ones
    http://localhost:8080/getAllProducts
    */
    @RequestMapping(value = "/getAllProducts", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public List<Product> getAllProducts() {
        List<Product> products = productService.getAllProducts();
        if (CollectionUtils.isEmpty(products)) {
            throw new ProductNotFoundException("No products available in the inventory");
        }
        return products;
    }

    /*
    End point to get all product details including advice to which product should be ordered and count to be ordered
    http://localhost:8080/getAllProducts
    */
    @RequestMapping(value = "/getProductsAdviceToOrder", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public List<Product> getProductsAdviceToOrder() {
        List<Product> products = productService.getAllProductsToOrder();
        if (CollectionUtils.isEmpty(products)) {
            throw new ProductNotFoundException("There are no products to be ordered currently");
        }
        return products;
    }

    /*
    End point to create products in database
   */
    @RequestMapping(value = "/createMultipleProducts", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Product> createMultipleProducts(@RequestBody final List<Product> products) {
        productService.saveProducts(products);
        return new ResponseEntity<Product>(HttpStatus.OK);
    }

    /*
  End point to update either minimumStockLevel or additional volume
  of specific product by Name
   http://localhost:8080/updateMinimumStockLevel
   Sample Json {"productName":"apple","minimumStockLevel":12}
   */
    @RequestMapping(value = "updateProductDetails", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Product> updateProductDetails(@RequestBody final Product product) {
        productService.updateProductDetails(product);
        return new ResponseEntity<Product>(HttpStatus.OK);
    }

    // for testing purpose only
    public void setProductService(ProductService productService) {
        this.productService = productService;
    }
}
