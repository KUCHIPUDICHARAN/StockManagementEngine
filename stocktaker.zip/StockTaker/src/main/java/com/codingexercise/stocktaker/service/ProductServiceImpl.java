package com.codingexercise.stocktaker.service;

import com.codingexercise.stocktaker.model.OrderState;
import com.codingexercise.stocktaker.model.Product;
import com.codingexercise.stocktaker.repository.ProductRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

@Service
public class ProductServiceImpl implements ProductService {

    @Autowired
    private ProductRepository productRepository;


    @Override
    public void saveProducts(List<Product> products) {
        productRepository.saveAll(products);
    }

    @Override
    public Product findProductByName(String name) {
        Objects.requireNonNull(name, "Product Name cannot be null as it is primarykey field to update");
        return (Product) productRepository.findByProductName(name);
    }

    @Override
    public List<Product> getAllProducts() {
        return (List<Product>) productRepository.findAll();
    }

    /*
    This is to get all products with status set based on stock level
    and to set stock to be ordered  based on current stock and
    any other additional volume
     */
    @Override
    public List<Product> getAllProductsToOrder() {
        List<Product> products = (List<Product>) productRepository.findAll();
        products = products.stream().filter(product ->
                null != product.getOrderState() &&
                        null != product.getCurrentStock() &&
                        null != product.getMinimumStockLevel() &&
                        !OrderState.BLOCKED.name().equals(product.getOrderState().name())
                        && product.getCurrentStock() < product.getMinimumStockLevel()
        ).collect(Collectors.toList());
        products.forEach(product -> {
            product.setOrderState(OrderState.SHOULD_ORDER);
            if (product.getCurrentStock() <= product.getMinimumStockLevel()) {
                product.setAmountOfStockToBeOrdered(product.getMinimumStockLevel() - product.getCurrentStock() + product.getAdditionalVolume());
            } else {
                product.setAmountOfStockToBeOrdered(product.getAdditionalVolume());
            }
        });
        return products;
    }

    @Override
    public void updateProductDetails(Product product) {
        Objects.requireNonNull(product.getProductName(), "Product Name cannot be null");
        Product product1 = (Product) productRepository.findByProductName(product.getProductName());
        Objects.requireNonNull(product1, "There is no product with the given name in database");
        if (null != product.getMinimumStockLevel()) {
            product1.setMinimumStockLevel(product.getMinimumStockLevel());
        }
        if (null != product.getAdditionalVolume()) {
            product1.setAdditionalVolume(product.getAdditionalVolume());
        }
        productRepository.save(product1);
    }

    public void setProductRepository(ProductRepository productRepository) {
        this.productRepository = productRepository;
    }
}
