package com.codingexercise.stocktaker.model;

public enum OrderState {

    SHOULD_ORDER,ALLOWED,BLOCKED
}
