package com.codingexercise.stocktaker.model;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import java.io.Serializable;

@Entity
@Table(name = "product")
public class Product implements Serializable {

    @Id
    @NotNull(message = "Product name is required.")
    @Column(name = "name")
    private String productName;

    @Column(name = "price")
    private Double price;

    @Column(name = "current_stock")
    private Integer currentStock;

    @Column(name = "additional_volume")
    private Integer additionalVolume;

    @Enumerated(EnumType.STRING)
    @Column(name = "order_state")
    private OrderState orderState;

    @Column(name = "minimum_stock_level")
    private Integer minimumStockLevel;

    @Column(name = "stock_to_order")
    private Integer AmountOfStockToBeOrdered;

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public Double getPrice() {
        return price;
    }

    public void setPrice(Double price) {
        this.price = price;
    }

    public Integer getCurrentStock() {
        return currentStock;
    }

    public void setCurrentStock(Integer currentStock) {
        this.currentStock = currentStock;
    }

    public Integer getAdditionalVolume() {
        return additionalVolume;
    }

    public void setAdditionalVolume(Integer additionalVolume) {
        this.additionalVolume = additionalVolume;
    }

    public OrderState getOrderState() {
        return orderState;
    }

    public void setOrderState(OrderState orderState) {
        this.orderState = orderState;
    }

    public Integer getMinimumStockLevel() {
        return minimumStockLevel;
    }

    public void setMinimumStockLevel(Integer minimumStockLevel) {
        this.minimumStockLevel = minimumStockLevel;
    }

    public Integer getAmountOfStockToBeOrdered() {
        return AmountOfStockToBeOrdered;
    }

    public void setAmountOfStockToBeOrdered(Integer amountOfStockToBeOrdered) {
        this.AmountOfStockToBeOrdered = amountOfStockToBeOrdered;
    }
}
