package com.codingexercise.stocktaker;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StockTakerApplication {

    public static void main(String[] args) {
        SpringApplication.run(StockTakerApplication.class, args);
    }

}
