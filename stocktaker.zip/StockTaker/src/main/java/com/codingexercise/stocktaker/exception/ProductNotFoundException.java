package com.codingexercise.stocktaker.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(value = HttpStatus.BAD_REQUEST)
public class ProductNotFoundException extends IllegalArgumentException {

    public ProductNotFoundException(final String message){
        super(message);
    }

}
