package com.codingexercise.stocktaker.helpers;

import com.codingexercise.stocktaker.model.OrderState;
import com.codingexercise.stocktaker.model.Product;

import java.util.ArrayList;
import java.util.List;

public class SampleData {
    public static List<Product> sampleListOfProducts() {
        List<Product> products = new ArrayList<Product>();
        products.add(createProduct("Apples", 1.00, 4, 6, 0, OrderState.ALLOWED));
        products.add(createProduct("Eggs", 1.00, 8, 3, 0, OrderState.ALLOWED));
        products.add(createProduct("Milk", 1.00, 8, 8, 5, OrderState.ALLOWED));
        products.add(createProduct("Bread", 1.00, 10, 0, 10, OrderState.ALLOWED));
        products.add(createProduct("Chicken", 1.00, 5, 2, 0, OrderState.ALLOWED));
        products.add(createProduct("Salad", 1.00, 5, 6, 0, OrderState.BLOCKED));
        return products;
    }


    public static Product createProduct(String name, Double price, Integer minimumStockLevel, Integer currentStock, Integer additionalVolume, OrderState orderState) {
        Product product = new Product();
        product.setProductName(name);
        product.setPrice(price);
        product.setMinimumStockLevel(minimumStockLevel);
        product.setCurrentStock(currentStock);
        product.setAdditionalVolume(additionalVolume);
        product.setOrderState(orderState);
        return product;
    }
}
