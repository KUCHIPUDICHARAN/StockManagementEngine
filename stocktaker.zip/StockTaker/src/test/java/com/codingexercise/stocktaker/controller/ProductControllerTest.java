package com.codingexercise.stocktaker.controller;

import com.codingexercise.stocktaker.helpers.SampleData;
import com.codingexercise.stocktaker.model.Product;
import com.codingexercise.stocktaker.repository.ProductRepository;
import com.codingexercise.stocktaker.service.ProductServiceImpl;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.json.JsonParseException;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import java.io.IOException;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

@SpringBootTest
@RunWith(SpringRunner.class)
public class ProductControllerTest {
    protected MockMvc mvc;

    private ProductController productController;


    private ProductServiceImpl productService;
    @Autowired
    private ProductRepository productRepository;

    @Before
    public void setUp() {
        productController = new ProductController();
        productService = new ProductServiceImpl();
        productService.setProductRepository(productRepository);
        productController.setProductService(productService);

        mvc = MockMvcBuilders.standaloneSetup(productController).build();
        List<Product> sampleData = SampleData.sampleListOfProducts();
        productRepository.saveAll(sampleData);

    }

    @After
    public void cleanUp() {
        productRepository.deleteAll();
    }

    @Test
    public void testCreateMultipleProducts() throws Exception {
        List<Product> sampleData = SampleData.sampleListOfProducts();
        String uri = "/createMultipleProducts";
        String inputJson = mapToJson(sampleData);
        MvcResult mvcResult = mvc.perform(MockMvcRequestBuilders.post(uri)
                .contentType(MediaType.APPLICATION_JSON_VALUE).content(inputJson)).andReturn();
        int status = mvcResult.getResponse().getStatus();
        assertEquals(200, status);
    }

    @Test
    public void getProductsList() throws Exception {
        String uri = "/getAllProducts";
        MvcResult mvcResult = mvc.perform(MockMvcRequestBuilders.get(uri)
                .accept(MediaType.APPLICATION_JSON_VALUE)).andReturn();

        int status = mvcResult.getResponse().getStatus();
        assertEquals(200, status);
        String content = mvcResult.getResponse().getContentAsString();
        List<Product> productList = mapFromJson(content, List.class);
        assertTrue(productList.size() == 6);
    }

    @Test
    public void updateProductDetails() throws Exception {
        String uri = "/updateProductDetails";
        Product product = new Product();
        product.setProductName("Apples");
        product.setMinimumStockLevel(5);
        product.setAdditionalVolume(1);
        String inputJson = mapToJson(product);

        MvcResult mvcResult = mvc.perform(MockMvcRequestBuilders.post(uri)
                .contentType(MediaType.APPLICATION_JSON_VALUE).content(inputJson))
                .andReturn();

        int status = mvcResult.getResponse().getStatus();
        assertEquals(200, status);
    }

    @Test
    public void getProductsAdviceToOrder() throws Exception {
        String uri = "/getProductsAdviceToOrder";
        MvcResult mvcResult = mvc.perform(MockMvcRequestBuilders.get(uri)
                .accept(MediaType.APPLICATION_JSON_VALUE)).andReturn();

        int status = mvcResult.getResponse().getStatus();
        assertEquals(200, status);
        String content = mvcResult.getResponse().getContentAsString();
        List<Product> productList = mapFromJson(content, List.class);
        assertTrue(productList.size() == 3);
    }

    protected <T> T mapFromJson(String json, Class<T> clazz)
            throws JsonParseException, JsonMappingException, IOException {

        ObjectMapper objectMapper = new ObjectMapper();
        return objectMapper.readValue(json, clazz);
    }

    protected String mapToJson(Object obj) throws JsonProcessingException {
        ObjectMapper objectMapper = new ObjectMapper();
        return objectMapper.writeValueAsString(obj);
    }

}
